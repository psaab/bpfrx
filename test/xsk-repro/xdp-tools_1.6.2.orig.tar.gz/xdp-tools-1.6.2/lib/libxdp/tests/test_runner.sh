#!/bin/bash
# SPDX-License-Identifier: GPL-2.0-or-later
#
# Script to setup and manage tests for xdp-tools.
# Based on the test-env script from xdp-tutorial.
#
# Author:   Toke Høiland-Jørgensen (toke@redhat.com)
# Date:     26 May 2020
# Copyright (c) 2020 Red Hat

set -o errexit
set -o nounset
umask 077

TEST_PROG_DIR="${TEST_PROG_DIR:-$(dirname "${BASH_SOURCE[0]}")}"
ALL_TESTS=""
VERBOSE_TESTS=${V:-0}

export VERBOSE_TESTS

# Odd return value for skipping, as only 0-255 is valid.
SKIPPED_TEST=249

is_func()
{
    type "$1" 2>/dev/null | grep -q 'is a function'
}

check_run()
{
    local ret

    [ "$VERBOSE_TESTS" -eq "1" ] && echo "$@"
    "$@"
    ret=$?
    if [ "$ret" -ne "0" ]; then
        exit $ret
    fi
}

exec_test()
{
    local testn="$1"
    local output
    local ret
    local prefix

    prefix=$(printf "     %-30s" "[$testn]")
    if ! is_func "$testn"; then
        echo "${prefix}INVALID"
        return 1
    fi

    if [ "$VERBOSE_TESTS" -eq "1" ]; then
        echo "${prefix}START:"
        ($testn 2>&1) | sed -u 's/^/          /'
        ret=${PIPESTATUS[0]}
        echo "          Test $testn exited with return code: $ret"
    else
        echo -n "$prefix"
        output=$($testn 2>&1)
        ret=$?
        prefix=
    fi

    if [ "$ret" -eq "0" ]; then
        echo "${prefix}PASS"
    elif [ "$ret" -eq "$SKIPPED_TEST" ]; then
        echo "${prefix}SKIPPED"
        ret=0
    else
        echo "${prefix}FAIL"
    fi
    if [ "$ret" -ne "0" ] && [ "$VERBOSE_TESTS" -ne "1" ]; then
        echo "$output" | sed  's/^/          /'
        echo "          Test $testn exited with return code: $ret"
    fi
    return $ret
}

run_tests()
{
    local TESTS="$*"
    local ret=0
    [ -z "$TESTS" ] && TESTS="$ALL_TESTS"

    echo "    Running tests from $TEST_DEFINITIONS"

    for testn in $TESTS; do
        exec_test $testn || ret=1
        if is_func cleanup_tests; then
            cleanup_tests || true
        fi
    done

    return $ret
}

usage()
{
    echo "Usage: $0 <test_definition_file> [test names]" >&2
    exit 1
}

if [ "$EUID" -ne "0" ]; then
    if command -v sudo >/dev/null 2>&1; then
        exec sudo env CC="$CC" CFLAGS="$CFLAGS" CPPFLAGS="$CPPFLAGS" LDLIBS="$LDLIBS" V=${VERBOSE_TESTS} "$0" "$@"
    else
        die "Tests must be run as root"
    fi
else
    if [ "${DID_UNSHARE:-0}" -ne "1" ]; then
        echo "Executing tests in separate net- and mount namespaces" >&2
        exec env DID_UNSHARE=1 unshare -n -m "$0" "$@"
    fi
fi

TEST_DEFINITIONS="${1:-}"
[ -f "$TEST_DEFINITIONS" ] || usage
source "$TEST_DEFINITIONS"

shift
run_tests "$@"
